let currentPlayer = "X";
let board = ["", "", "", "", "", "", "", "", ""];
let playerXWins = 0;
let playerOWins = 0;

const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // filas
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // columnas
    [0, 4, 8], [2, 4, 6] // diagonales
];

function changeLanguage() {
    const selectedLanguage = document.getElementById("language-select").value;
    updateInterfaceText(selectedLanguage);
}

function updateInterfaceText(language) {
    const texts = {
        'es': {
            'title2': 'DIFICIL',
            'title': 'Tres En Raya',
            'selectLanguage': 'Selecciona el idioma:',
            'restartButton': 'Reiniciar',
            'playerTurn': 'Turno de %s',
            'playerWin': '¡%s Gana!',
            'tieGame': '¡Empate!',
            'scoreboard': 'Jugador "X": %d | IA "O": %d'
        },
        'en': {
            'title2': 'HARD',
            'title': 'Tic Tac Toe',
            'selectLanguage': 'Select language:',
            'restartButton': 'Restart',
            'playerTurn': 'Player %s\'s turn',
            'playerWin': 'Player %s wins!',
            'tieGame': 'It\'s a tie!',
            'scoreboard': 'Player X: %d | IA O: %d'
        }
    };

    document.querySelector('.title').innerText = texts[language]['title'];
    document.querySelector('.title2').innerText = texts[language]['title2'];
    document.querySelector('label[for="language-select"]').innerText = texts[language]['selectLanguage'];
    document.getElementById('resetButton').innerText = texts[language]['restartButton'];
    updateMessage(language, currentPlayer);
    updateScoreboard();
}

function updateMessage(language, player) {
    const texts = {
        'es': {
            'playerTurn': 'Turno de %s',
            'playerWin': '¡%s Gana!',
            'tieGame': '¡Es un empate!'
        },
        'en': {
            'playerTurn': 'Player %s\'s turn',
            'playerWin': 'Player %s wins!',
            'tieGame': 'It\'s a tie!'
        }
    };

    let message;
    if (player === "tie") {
        message = texts[language]['tieGame'];
    } else if (player === "X" || player === "O") {
        message = texts[language]['playerTurn'].replace('%s', player);
    }

    document.getElementById("message").innerText = message;
}

function makeMove(index) {
    if (board[index] === "" && !checkWinner()) {
        board[index] = currentPlayer;
        document.getElementsByClassName("cell")[index].innerText = currentPlayer;

        if (checkWinner()) {
            handleWin();
        } else if (board.every(cell => cell !== "")) {
            handleTie();
        } else {
            currentPlayer = currentPlayer === "X" ? "O" : "X";
            if (currentPlayer === "O") {
                setTimeout(aiMove, 700); // La IA hace su movimiento después de 500ms
            }
            updateMessage(document.getElementById("language-select").value, currentPlayer);
        }
    }
}

function aiMove() {
    let bestScore = -Infinity;
    let bestMove;
    for (let i = 0; i < board.length; i++) {
        if (board[i] === "") {
            board[i] = "O";
            let score = minimax(board, 0, false);
            board[i] = "";
            if (score > bestScore) {
                bestScore = score;
                bestMove = i;
            }
        }
    }
    makeMove(bestMove);
}

const scores = {
    "O": 1,
    "X": -1,
    "tie": 0
};

function minimax(board, depth, isMaximizing) {
    let winner = checkWinner();
    if (winner !== null) {
        return scores[winner];
    }
    if (board.every(cell => cell !== "")) {
        return scores["tie"];
    }

    if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < board.length; i++) {
            if (board[i] === "") {
                board[i] = "O";
                let score = minimax(board, depth + 1, false);
                board[i] = "";
                bestScore = Math.max(score, bestScore);
            }
        }
        return bestScore;
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < board.length; i++) {
            if (board[i] === "") {
                board[i] = "X";
                let score = minimax(board, depth + 1, true);
                board[i] = "";
                bestScore = Math.min(score, bestScore);
            }
        }
        return bestScore;
    }
}

function handleWin() {
    let winner = checkWinner();
    if (winner === "X") {
        playerXWins++;
    } else if (winner === "O") {
        playerOWins++;
    }
    updateScoreboard();
    const language = document.getElementById("language-select").value;
    document.getElementById("message").innerText = language === 'es' ? `¡${winner} Gana!` : `${winner} wins!`;
    
    // Marcar las casillas ganadoras en verde
    winPatterns.forEach(pattern => {
        const [a, b, c] = pattern;
        if (board[a] !== "" && board[a] === board[b] && board[a] === board[c]) {
            document.getElementsByClassName("cell")[a].classList.add('winner');
            document.getElementsByClassName("cell")[b].classList.add('winner');
            document.getElementsByClassName("cell")[c].classList.add('winner');
        }
    });

    // Añadir la clase de animación al marcador de victorias solo al ganar
    document.getElementById("scoreboard").classList.add('scoreboard-animation');
    setTimeout(() => {
        document.getElementById("scoreboard").classList.remove('scoreboard-animation');
    }, 300); // Tiempo de espera debe coincidir con la duración de la animación en CSS (0.3s = 300ms)
}

function handleTie() {
    const language = document.getElementById("language-select").value;
    currentPlayer = "tie";
    updateMessage(language, "tie");
}

function updateScoreboard() {
    const language = document.getElementById("language-select").value;
    const scoreboardText = language === 'es' ? 'Jugador "X": %d | IA "O": %d' : 'Player "X": %d | IA "O": %d';
    const formattedScoreboard = scoreboardText.replace('%d', playerXWins).replace('%d', playerOWins);
    const scoreboardElement = document.getElementById("scoreboard");

    scoreboardElement.innerText = formattedScoreboard;
}

function checkWinner() {
    for (let pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            return board[a];
        }
    }
    return null;
}

function resetGame() {
    currentPlayer = "X";
    board = ["", "", "", "", "", "", "", "", ""];
    const cells = document.getElementsByClassName("cell");
    for (let cell of cells) {
        cell.innerText = "";
        cell.classList.remove('winner'); // Remover la clase 'winner'
    }
    document.getElementById("message").innerText = "";
    updateScoreboard();
    updateInterfaceText(document.getElementById("language-select").value);
}

// Actualizar el mensaje de turno inicial al cargar la página
document.addEventListener('DOMContentLoaded', () => {
    updateInterfaceText(document.getElementById("language-select").value);
});